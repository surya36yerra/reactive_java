#!/bin/sh
# The script sets environment variables helpful for PostgreSQL

export PATH=/Users/syerr3/postgresql/bin:$PATH
export PGDATA=/Users/syerr3/postgresdata
export PGDATABASE=postgres
export PGUSER=postgres
export PGPORT=5432
export PGLOCALEDIR=/Users/syerr3/postgresql/share/locale
export MANPATH=$MANPATH:/Users/syerr3/postgresql/share/man

                            